// ============================================
// CAR PRICE PREDICTION APP - MAIN SCRIPT
// ============================================

/**
 * DOM Element References
 */
const DOM_ELEMENTS = {
  themeToggleButton: document.getElementById('themeToggleButton'),
  predictionForm: document.getElementById('predictionForm'),
  submitButton: document.getElementById('submitButton'),
  submitButtonLoader: document.getElementById('submitButtonLoader'),
  themeToggleIcon: document.querySelector('.theme-toggle-icon'),
  resultContainer: document.getElementById('resultContainer'),
};

/**
 * Application Constants
 */
const APP_CONFIG = {
  THEME_STORAGE_KEY: 'carprice-theme-preference',
  DARK_MODE_CLASS: 'dark-mode',
  LOADING_CLASS: 'is-loading',
  FORM_SUBMISSION_TIMEOUT: 3000,
  ANIMATION_DURATION: 300,
};

/**
 * Theme Management System
 */
const ThemeManager = {
  /**
   * Initialize theme from localStorage or system preference
   */
  initializeTheme() {
    const savedTheme = localStorage.getItem(APP_CONFIG.THEME_STORAGE_KEY);
    const prefersDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const shouldUseDarkMode = savedTheme ? savedTheme === 'dark' : prefersDarkMode;

    if (shouldUseDarkMode) {
      this.enableDarkMode();
    } else {
      this.disableDarkMode();
    }
  },

  /**
   * Enable dark mode theme
   */
  enableDarkMode() {
    document.body.classList.add(APP_CONFIG.DARK_MODE_CLASS);
    this.updateThemeToggleIcon(true);
    localStorage.setItem(APP_CONFIG.THEME_STORAGE_KEY, 'dark');
  },

  /**
   * Disable dark mode theme (use light mode)
   */
  disableDarkMode() {
    document.body.classList.remove(APP_CONFIG.DARK_MODE_CLASS);
    this.updateThemeToggleIcon(false);
    localStorage.setItem(APP_CONFIG.THEME_STORAGE_KEY, 'light');
  },

  /**
   * Toggle theme mode
   */
  toggleTheme() {
    const isDarkModeEnabled = document.body.classList.contains(APP_CONFIG.DARK_MODE_CLASS);
    
    if (isDarkModeEnabled) {
      this.disableDarkMode();
    } else {
      this.enableDarkMode();
    }
  },

  /**
   * Update theme toggle button icon based on current theme
   * @param {boolean} isDarkMode - Whether dark mode is enabled
   */
  updateThemeToggleIcon(isDarkMode) {
    if (DOM_ELEMENTS.themeToggleIcon) {
      DOM_ELEMENTS.themeToggleIcon.textContent = isDarkMode ? '☀️' : '🌙';
    }
  },
};

/**
 * Form Interaction Manager
 */
const FormManager = {
  /**
   * Initialize form event listeners
   */
  initializeFormListeners() {
    if (DOM_ELEMENTS.predictionForm) {
      DOM_ELEMENTS.predictionForm.addEventListener('submit', (event) => {
        this.handleFormSubmit(event);
      });
    }

    // Add input validation feedback
    this.setupInputValidationFeedback();
  },

  /**
   * Handle form submission
   * @param {Event} event - The form submission event
   */
  handleFormSubmit(event) {
    // Allow default form submission to the server
    if (DOM_ELEMENTS.submitButton) {
      this.showLoadingState();
    }
  },

  /**
   * Display loading state on submit button
   */
  showLoadingState() {
    DOM_ELEMENTS.submitButton.disabled = true;
    DOM_ELEMENTS.submitButton.classList.add(APP_CONFIG.LOADING_CLASS);
  },

  /**
   * Hide loading state on submit button
   */
  hideLoadingState() {
    if (DOM_ELEMENTS.submitButton) {
      DOM_ELEMENTS.submitButton.disabled = false;
      DOM_ELEMENTS.submitButton.classList.remove(APP_CONFIG.LOADING_CLASS);
    }
  },

  /**
   * Setup real-time validation feedback for form inputs
   */
  setupInputValidationFeedback() {
    const formInputs = DOM_ELEMENTS.predictionForm.querySelectorAll('.form-input, .form-select');
    
    formInputs.forEach((inputElement) => {
      inputElement.addEventListener('blur', (event) => {
        this.validateInputField(event.target);
      });

      inputElement.addEventListener('focus', (event) => {
        this.clearInputError(event.target);
      });
    });
  },

  /**
   * Validate individual input field
   * @param {HTMLElement} inputElement - The input element to validate
   */
  validateInputField(inputElement) {
    if (!inputElement.value.trim()) {
      this.showInputError(inputElement, 'This field is required');
    }
  },

  /**
   * Display error message for input field
   * @param {HTMLElement} inputElement - The input element
   * @param {string} errorMessage - Error message to display
   */
  showInputError(inputElement, errorMessage) {
    // Add visual feedback (can be enhanced with error message display)
    inputElement.style.borderColor = '#ef4444';
  },

  /**
   * Clear error state from input field
   * @param {HTMLElement} inputElement - The input element
   */
  clearInputError(inputElement) {
    inputElement.style.borderColor = '';
  },
};

/**
 * Result Display Manager
 */
const ResultManager = {
  /**
   * Show result container with animation
   */
  displayResultContainer() {
    if (DOM_ELEMENTS.resultContainer) {
      DOM_ELEMENTS.resultContainer.style.opacity = '0';
      DOM_ELEMENTS.resultContainer.style.transform = 'translateY(20px)';
      
      setTimeout(() => {
        DOM_ELEMENTS.resultContainer.style.transition = `all ${APP_CONFIG.ANIMATION_DURATION}ms cubic-bezier(0.4, 0, 0.2, 1)`;
        DOM_ELEMENTS.resultContainer.style.opacity = '1';
        DOM_ELEMENTS.resultContainer.style.transform = 'translateY(0)';
      }, 50);
    }
  },

  /**
   * Hide result container
   */
  hideResultContainer() {
    if (DOM_ELEMENTS.resultContainer) {
      DOM_ELEMENTS.resultContainer.style.opacity = '0';
      DOM_ELEMENTS.resultContainer.style.transform = 'translateY(20px)';
    }
  },
};

/**
 * Analytics Tracking (placeholder for future enhancement)
 */
const AnalyticsTracker = {
  /**
   * Track form submission event
   */
  trackFormSubmission() {
    // Placeholder for analytics implementation
    console.log('Form submitted for car price prediction');
  },

  /**
   * Track theme change event
   */
  trackThemeChange() {
    // Placeholder for analytics implementation
    console.log('User changed theme preference');
  },
};

/**
 * Application Initialization
 */
const AppInitializer = {
  /**
   * Initialize all app components when DOM is ready
   */
  init() {
    // Initialize theme manager
    ThemeManager.initializeTheme();

    // Setup theme toggle button
    if (DOM_ELEMENTS.themeToggleButton) {
      DOM_ELEMENTS.themeToggleButton.addEventListener('click', () => {
        ThemeManager.toggleTheme();
        AnalyticsTracker.trackThemeChange();
      });
    }

    // Initialize form manager
    FormManager.initializeFormListeners();

    // Display results if available
    if (DOM_ELEMENTS.resultContainer) {
      ResultManager.displayResultContainer();
    }

    // Log successful initialization
    console.log('CarPrice Prediction App initialized successfully');
  },
};

/**
 * DOM Ready Event Listener
 */
document.addEventListener('DOMContentLoaded', () => {
  AppInitializer.init();
});
