from flask import Flask, request, render_template
import pickle
import pandas as pd

app = Flask(__name__)

# Load trained Ridge pipeline
model = pickle.load(open('ridge_pipeline.pkl', 'rb'))


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    name = request.form['name']
    year = int(request.form['year'])
    km_driven = int(request.form['km_driven'])
    fuel = request.form['fuel']
    seller_type = request.form['seller_type']
    transmission = request.form['transmission']
    owner = request.form['owner']

    # Create input dataframe
    input_data = pd.DataFrame({
        'name': [name],
        'year': [year],
        'km_driven': [km_driven],
        'fuel': [fuel],
        'seller_type': [seller_type],
        'transmission': [transmission],
        'owner': [owner]
    })

    prediction = model.predict(input_data)[0]

    return render_template(
        'index.html',
        prediction_text=f"Predicted Car Price: ₹ {round(prediction, 2)}"
    )


if __name__ == '__main__':
    app.run(debug=True)